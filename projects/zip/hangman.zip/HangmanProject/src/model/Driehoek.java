package model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

import java.util.ArrayList;

public class Driehoek extends Vorm {
    private Punt hoekPunt1,hoekPunt2,hoekPunt3;

    public Driehoek(Punt hoekPunt1, Punt hoekPunt2, Punt hoekPunt3){
        super();
        if (hoekpuntIsLeeg(hoekPunt1)){
            throw new DomainException("Hoekpunt 1 mag niet leeg zijn");
        }
        if (hoekpuntIsLeeg(hoekPunt2)){
            throw new DomainException("Hoekpunt 1 mag niet leeg zijn");
        }
        if (hoekpuntIsLeeg(hoekPunt3)){
            throw new DomainException("Hoekpunt 1 mag niet leeg zijn");
        }
        if (hoekPunt1.equals(hoekPunt2) || hoekPunt1.equals(hoekPunt3) || hoekPunt2.equals(hoekPunt3)){
            throw new DomainException("Alle hoekpunten moeten verschillend zijn");
        }
        if (liggenOp1Lijn(hoekPunt1,hoekPunt2,hoekPunt3)){
            throw new DomainException("Hoekpunten mogen niet op één lijn liggen");
        }
        this.hoekPunt1 = hoekPunt1;
        this.hoekPunt2 = hoekPunt2;
        this.hoekPunt3 = hoekPunt3;
    }

    private static boolean hoekpuntIsLeeg(Punt hoekPunt){
        if (hoekPunt == null){
            return true;
        }
        return false;
    }

    public Punt getHoekPunt1() {
        return hoekPunt1;
    }

    public Punt getHoekPunt2() {
        return hoekPunt2;
    }

    public Punt getHoekPunt3() {
        return hoekPunt3;
    }

    private static boolean liggenOp1Lijn(Punt hoekPunt1, Punt hoekPunt2, Punt hoekPunt3){
        return (hoekPunt2.getX() - hoekPunt1.getX())*(hoekPunt3.getY() - hoekPunt1.getY()) == (hoekPunt3.getX() - hoekPunt1.getX())*(hoekPunt2.getY() - hoekPunt1.getY());
    }

    private void sorteerHoekpunten(){
        ArrayList<Punt> lijst = new ArrayList<>();
        lijst.add(hoekPunt1);
        lijst.add(hoekPunt2);
        lijst.add(hoekPunt3);
        lijst.sort(Punt::compareTo);
        hoekPunt1 = lijst.get(0);
        hoekPunt2 = lijst.get(1);
        hoekPunt3 = lijst.get(2);
    }

    @Override
    public Omhullende getOmhullende(){
        sorteerHoekpunten();
        int minX = hoekPunt1.getX();
        int maxX = hoekPunt3.getX();
        int minY = Math.min(hoekPunt1.getY(),Math.min(hoekPunt2.getY(),hoekPunt3.getY()));
        int maxY = Math.max(hoekPunt1.getY(),Math.max(hoekPunt2.getY(),hoekPunt3.getY()));
        return new Omhullende(new Punt(minX,minY),Math.abs(maxX-minX),Math.abs(maxY-minY));
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof Driehoek){
            Driehoek driehoek = (Driehoek)o;
            this.sorteerHoekpunten();
            driehoek.sorteerHoekpunten();
            return hoekPunt1.equals(driehoek.hoekPunt1) && hoekPunt2.equals(driehoek.hoekPunt2) && hoekPunt3.equals(driehoek.hoekPunt3);
        }
        return false;
    }

    @Override
    public String toString(){
        this.sorteerHoekpunten();
        return "Driehoek: hoekpunt1: " + hoekPunt1.toString() + " - hoekpunt2: " + hoekPunt2.toString() + " - hoekpunt3: " + hoekPunt3.toString() + "\n" + getOmhullende().toString();
    }

    @Override
    public void teken(Pane root) {
        Polygon shape = new Polygon();
        int[] pointsINT = {hoekPunt1.getX(),hoekPunt1.getY(),hoekPunt2.getX(),hoekPunt2.getY(),hoekPunt3.getX(),hoekPunt3.getY()};
        Double[] pointsDOUBLE = new Double[pointsINT.length];
        for (int i = 0; i < pointsINT.length; i++){
            pointsDOUBLE[i] = Double.valueOf(pointsINT[i]);
        }
        shape.getPoints().addAll(pointsDOUBLE);
        shape.setFill(super.getKleur());
        shape.setStroke(Color.BLACK);
        root.getChildren().add(shape);
    }
}