package model;

import javafx.scene.layout.Pane;

public interface Drawable {
    void teken(Pane root);
}
