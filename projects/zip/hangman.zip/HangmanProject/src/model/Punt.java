package model;

public class Punt{
    private int x;
    private int y;

    public Punt(int x, int y){
        this.x = x;
        this.y = y;
    }

    private void setX(int x) {
        this.x = x;
    }

    private void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Punt) {
            Punt punt = ((Punt) o);
            return punt.x == this.x &&
                    punt.y == this.y;
        }
        return false;
    }

    @Override
    public String toString() {
        return "(" + x + " , " + y + ")";
    }

    public int compareTo(Punt punt) {
        if (punt == null){
            throw new DomainException("Het punt dat je wilt vergelijken mag niet leeg zijn");
        }
        return x == punt.x? y - punt.y : x - punt.x;
    }
}