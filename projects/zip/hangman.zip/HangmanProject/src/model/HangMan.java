package model;

import db.WoordenLijstTabel;

public class HangMan {
    private Speler speler;
    private TekeningHangMan tekeningHangMan;
    private HintWoord hintWoord;
    private boolean gewonnen;

    public HangMan(Speler speler){
        setSpeler(speler);
        tekeningHangMan = new TekeningHangMan();
        hintWoord = new HintWoord(WoordenLijstTabel.getRandomWoord().getWoord());
    }

    private void setSpeler(Speler speler) {
        if (speler == null){
            throw new DomainException("Speler mag niet leeg zijn");
        }
        this.speler = speler;
    }

    public Speler getSpeler(){
        return speler;
    }

    public TekeningHangMan getTekening(){
        return tekeningHangMan;
    }

    public String getHint(){
        return hintWoord.toString();
    }

    public boolean isGameOver(){
        return tekeningHangMan.getAantalOnzichtbaar() == 0;
    }

    public boolean isGewonnen(){
        return gewonnen;
    }

    public boolean raad(char letter){
        if (!hintWoord.raad(letter)){
            tekeningHangMan.zetVolgendeZichtbaar();
            return false;
        }
        speler.addToScore(1);
        if (hintWoord.isGeraden()){
            speler.addToScore(tekeningHangMan.getAantalOnzichtbaar());
            gewonnen = true;
        }
        return true;
    }
}