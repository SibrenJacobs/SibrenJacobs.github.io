package model;

import java.util.ArrayList;
import java.util.List;

public class Woord {
    private String woord, niveau;

    public Woord(String woord,String niveau){
        setWoord(woord);
        this.niveau = niveau;
    }
    public Woord(String woord){
        setWoord(woord);
    }

    public static Woord WoordDefaultNiveau(String woord){
        Woord result = new Woord(woord);
        result.setNiveau();
        return result;
    }

    private void setWoord(String woord) {
        if (woord == null || woord.trim().isEmpty()) {
            throw new DomainException("Woord mag niet leeg zijn");
        }
        this.woord = woord;
    }

    private void setNiveau() {
        if (woord.length() < 10) {
            niveau = "Gemakkelijk";
        } else if (woord.length() < 20) {
            niveau = "Gemiddeld";
        } else if (woord.length() < 30) {
            niveau = "Moeilijk";
        } else niveau = "Expert";
    }

    @Override
    public String toString() {
        if (niveau == null || niveau.trim().isEmpty()) {
            return woord;
        }
        return niveau + " | " + woord;
    }

    public String getWoord() {
        return woord;
    }

    public String getNiveau() {
        return niveau;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Woord) {
            return this.woord.equals(((Woord) o).woord) && this.niveau.equals(((Woord) o).niveau);
        }
        return false;
    }

    public static int getVerschillendeLetters(String woord){
        List<Character> chars = new ArrayList<>();
        for (int i = 0; i < woord.length(); i++){
            if (!chars.contains(woord.charAt(i))){
                chars.add(woord.charAt(i));
            }
        }
        return chars.size();
    }
}