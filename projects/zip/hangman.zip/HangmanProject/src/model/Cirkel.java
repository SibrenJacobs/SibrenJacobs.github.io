package model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Cirkel extends Vorm{
   private Punt middelPunt;
   private int radius;

    public Cirkel(Punt middelPunt, int radius) {
        super();
        setMiddelPunt(middelPunt);
        setRadius(radius);
    }

    private void setMiddelPunt(Punt middelPunt) {
        if (middelPunt == null) throw new DomainException("Het middelpunt mag niet leeg zijn");
        this.middelPunt = middelPunt;
    }

    private void setRadius(int radius) {
        if (radius <= 0) throw new DomainException("De straal moet groter zijn dan 0");
        this.radius = radius;
    }

    public Punt getMiddelPunt() {
        return middelPunt;
    }

    public int getRadius() {
        return this.radius;
    }

    @Override
    public Omhullende getOmhullende(){
        return new Omhullende(new Punt(middelPunt.getX()-radius,middelPunt.getY()-radius),radius * 2,radius * 2);
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Cirkel) {
            Cirkel c = (Cirkel) o;
            return this.getMiddelPunt().equals(c.getMiddelPunt())
                    && this.getRadius()== c.getRadius();

        }
        return false;
    }

    @Override
    public String toString() {
        return "Cirkel: middelpunt: " + middelPunt.toString() + " - straal: " + radius + "\n" + getOmhullende().toString();
    }

    @Override
    public void teken(Pane root) {
        Circle circle = new Circle(middelPunt.getX(),middelPunt.getY(),radius);
        circle.setFill(super.getKleur());
        circle.setStroke(Color.BLACK);
        root.getChildren().add(circle);
    }
}
