package model;

public class HintWoord {
    private HintLetter[] hintwoord;

    public HintWoord(String woord){
        setHintwoord(woord);
    }

    private void setHintwoord(String woord){
        if (woord == null || woord.trim().isEmpty()){
            throw new DomainException("Hintwoord mag niet leeg zijn");
        }
        this.hintwoord = stringToHintLetterArray(woord);
    }

    private static HintLetter[] stringToHintLetterArray(String woord){
        HintLetter[] result = new HintLetter[woord.length()];
        for (int i = 0; i < woord.length(); i++){
            result[i] = new HintLetter(woord.charAt(i));
        }
        return result;
    }

    public boolean raad(char letter){
        boolean letterGeraden = false;
        for (HintLetter hintLetter : hintwoord){
            if (hintLetter.raad(letter)){
                letterGeraden = true;
            }
        }
        return letterGeraden;
    }

    public boolean isGeraden(){
        for (HintLetter hintLetter : hintwoord){
            if (!hintLetter.isGeraden()){
                return  false;
            }
        }
        return true;
    }

    public String getWoord(){
        String result = "";
        for (HintLetter hintLetter : hintwoord){
            result += hintLetter.getLetter();
        }
        return result;
    }

    @Override
    public String toString(){
        String result = "";
        for (HintLetter letter : hintwoord){
            result += letter.toChar() + " ";
        }
        return result.trim();
    }
}