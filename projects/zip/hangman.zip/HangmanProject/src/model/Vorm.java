package model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public abstract class Vorm implements Drawable {
    private Color kleur;
    private boolean isZichtbaar;

    public Vorm(){
        kleur = Color.WHITE;
        isZichtbaar = true;
    }

    public Color getKleur() {
        return kleur;
    }

    public void setKleur(Color kleur) {
        if(kleur == null) {
            throw new DomainException("Kleur mag niet leeg zijn");
        }
        this.kleur = kleur;
    }

    public abstract Omhullende getOmhullende();

    public abstract String toString();

    public abstract void teken(Pane root);

    public boolean isZichtbaar(){
        return isZichtbaar;
    }

    public void setZichtbaar(boolean isZichtbaar){
        this.isZichtbaar = isZichtbaar;
    }
}