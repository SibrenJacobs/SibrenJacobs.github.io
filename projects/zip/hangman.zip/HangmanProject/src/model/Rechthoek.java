package model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Rechthoek extends Vorm{
    private int breedte,hoogte;
    private Punt linkerBovenhoek;

    public Rechthoek(Punt linkerBovenhoek, int breedte, int hoogte){
        super();
        setBreedte(breedte);
        setHoogte(hoogte);
        setLinkerBovenhoek(linkerBovenhoek);
    }

    private static boolean isPositief(int number){
        return number > 0;
    }

    private void setBreedte(int breedte){
        if (!isPositief(breedte)){
            throw new DomainException("Breedte moet strikt positief zijn");
        }
        this.breedte = breedte;
    }

    private void setHoogte(int hoogte){
        if (!isPositief(hoogte)){
            throw new DomainException("Hoogte moet strikt positief zijn");
        }
        this.hoogte = hoogte;
    }

    private void setLinkerBovenhoek(Punt linkerBovenhoek){
        if (linkerBovenhoek == null){
            throw new DomainException("Linkerbovenhoek mag niet leeg zijn");
        }
        this.linkerBovenhoek = linkerBovenhoek;
    }

    public int getBreedte() {
        return breedte;
    }

    public int getHoogte() {
        return hoogte;
    }

    public Punt getLinkerBovenhoek() {
        return linkerBovenhoek;
    }

    @Override
    public Omhullende getOmhullende(){
        return new Omhullende(linkerBovenhoek,breedte,hoogte);
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof Rechthoek){
            return breedte == ((Rechthoek) o).breedte && hoogte == ((Rechthoek) o).hoogte && linkerBovenhoek.equals(((Rechthoek) o).linkerBovenhoek);
        }
        return false;
    }

    @Override
    public String toString() {
        return "Rechthoek: linkerbovenhoek " + linkerBovenhoek.toString() + " - breedte: " + breedte + " - hoogte: " + hoogte + "\n" + getOmhullende().toString();
    }

    @Override
    public void teken(Pane root) {
        Rectangle rechthoek = new Rectangle(linkerBovenhoek.getX(),linkerBovenhoek.getY(),breedte,hoogte);
        rechthoek.setFill(super.getKleur());
        rechthoek.setStroke(Color.BLACK);
        root.getChildren().add(rechthoek);
    }
}