package model;

public class HintLetter {
    private char letter;
    private boolean isGeraden;

    public HintLetter(char letter) {
        setLetter(letter);
    }

    private static boolean isEmptyChar(char letter) {
        return letter == ' ';
    }

    private void setLetter(char letter) {
        if (isEmptyChar(letter)) {
            isGeraden = true;
        }
        this.letter = letter;
    }

    public char getLetter() {
        return letter;
    }

    public boolean raad(char letter) {
        if (isEmptyChar(letter)) {
            throw new DomainException("Letter mag niet leeg zijn");
        }
        if (!isGeraden && Character.toLowerCase(this.letter) == Character.toLowerCase(letter)) {
            isGeraden = true;
            return true;
        }
        return false;
    }

    public char toChar() {
        if (isGeraden) {
            return this.letter;
        }
        return '_';
    }

    public boolean isGeraden() {
        return isGeraden;
    }
}