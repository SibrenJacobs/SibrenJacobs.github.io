package model;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

public class LijnStuk extends Vorm {
    private Punt startPunt,eindPunt;

    public LijnStuk(Punt startPunt, Punt eindPunt){
        setStartEnEindPunt(startPunt,eindPunt);
    }

    private void setStartEnEindPunt(Punt startPunt, Punt eindPunt) {
        if (eindPunt == null || startPunt == null){
            throw new DomainException("Startpunt of eindpunt mogen niet leeg zijn");
        }
        if (startPunt.equals(eindPunt)){
            throw new DomainException("Startpunt en eindpunt mogen niet gelijk zijn");
        }
        this.startPunt = startPunt;
        this.eindPunt = eindPunt;
    }

    public Punt getEindPunt() {
        return eindPunt;
    }

    public Punt getStartPunt() {
        return startPunt;
    }

    @Override
    public Omhullende getOmhullende(){
        int minX = Math.min(startPunt.getX(),eindPunt.getX());
        int maxX = Math.max(startPunt.getX(),eindPunt.getX());
        int minY = Math.min(startPunt.getY(),eindPunt.getY());
        int maxY = Math.max(startPunt.getY(),eindPunt.getY());
        return new Omhullende(new Punt(minX,minY),Math.abs(maxX-minX),Math.abs(maxY-minY));
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof LijnStuk){
            return (startPunt.equals(((LijnStuk) o).startPunt) && eindPunt.equals(((LijnStuk) o).eindPunt))
                    || (startPunt.equals(((LijnStuk) o).eindPunt) && eindPunt.equals(((LijnStuk) o).startPunt));
        }
        return false;
    }

    @Override
    public String toString(){
        return "Lijn: startpunt: " + startPunt.toString() + " - eindpunt: " + eindPunt.toString() + "\n" + getOmhullende().toString();
    }

    @Override
    public void teken(Pane root) {
        Line lijn = new Line(startPunt.getX(),startPunt.getY(),eindPunt.getX(),eindPunt.getY());
        lijn.setStroke(Color.BLACK);
        lijn.setStrokeWidth(5);
        root.getChildren().add(lijn);
    }
}