package model;

public class Speler{
    private String naam;
    private int score;

    public Speler(String naam){
        setNaam(naam);
        score = 0;
    }

    private void setNaam(String naam){
        if (!isGeldigeNaam(naam)){
            throw new DomainException("Naam moet minstens 1 niet spatie bevatten");
        }
        this.naam = naam;
    }

    private static boolean isGeldigeNaam(String naam){
        return naam != null && !naam.trim().isEmpty();
    }

    public String getNaam(){
        return naam;
    }

    public int getScore(){
        return score;
    }

    public void addToScore(int aantal){
        if (score + aantal < 0){
            throw new DomainException("Resulterende score is negatief");
        }
        score += aantal;
    }

    @Override
    public boolean equals(Object o){
        if (o  instanceof Speler){
            return naam.equals(((Speler) o).naam) && score == ((Speler) o).score;
        }
        return false;
    }

    @Override
    public String toString(){
        return naam + " heeft als score " + score;
    }
}