package model;

public class Omhullende {
    private Punt linkerBovenhoek;
    private int breedte;
    private int hoogte;

    public Omhullende(Punt linkerBovenhoek, int breedte, int hoogte){
        setLinkerBovenhoek(linkerBovenhoek);
        setBreedte(breedte);
        setHoogte(hoogte);
    }

    public Punt getLinkerBovenhoek() {
        return linkerBovenhoek;
    }

    private void setLinkerBovenhoek(Punt positieLinksBoven) {
        if(positieLinksBoven == null){
            throw new DomainException("Linkerbovenhoek mag niet leeg zijn");
        }
        this.linkerBovenhoek = positieLinksBoven;
    }

    public int getBreedte() {
        return breedte;
    }

    private void setBreedte(int breedte) {
        if(breedte < 0){throw new DomainException("Breedte moet positief zijn");
        }
        this.breedte = breedte;
    }

    public int getHoogte() {
        return hoogte;
    }

    private void setHoogte(int hoogte) {
        if(hoogte < 0){throw new DomainException("Hoogte moet positief zijn");
        }
        this.hoogte = hoogte;
    }

    public int getMinimumX(){
        return linkerBovenhoek.getX();
    }

    public int getMinimumY(){
        return linkerBovenhoek.getY();
    }

    public int getMaximumX(){
        return linkerBovenhoek.getX() + breedte;
    }

    public int getMaximumY(){
        return linkerBovenhoek.getY() + hoogte;
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof Omhullende) {
            Omhullende omhullende = ((Omhullende) o);
            return linkerBovenhoek.equals(omhullende.linkerBovenhoek) &&
                    omhullende.breedte == this.breedte &&
                    omhullende.hoogte == this.hoogte;
        }
        return false;
    }

    @Override
    public String toString(){
        return "Omhullende: (" + linkerBovenhoek.getX() + ", " + linkerBovenhoek.getY() + ") - " + breedte + " - " + hoogte;
    }
}