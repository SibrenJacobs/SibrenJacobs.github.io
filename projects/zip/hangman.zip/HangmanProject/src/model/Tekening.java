package model;

import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.List;

public class Tekening implements Drawable{
    private String naam;
    protected List<Vorm> vormen = new ArrayList<>();
    public static final int MIN_X = 0;
    public static final int MAX_X = 399;
    public static final int MIN_Y = 0;
    public static final int MAX_Y = 399;

    public Tekening(String naam){
        setNaam(naam);
    }

    private void setNaam(String naam){
        if (!isValidNaam(naam)){
            throw new DomainException("Naam mag niet leeg zijn");
        }
        this.naam = naam;
    }

    public static boolean isValidNaam(String string){
        return string != null && !string.trim().isEmpty();
    }

    public String getNaam() {
        return naam;
    }

    public void voegToe(Vorm vorm){
        if (vorm == null){
            throw new DomainException("Vorm mag niet leeg zijn");
        }
        if (bevat(vorm)){
            throw new DomainException("Deze vorm zit al in de tekening");
        }
        Omhullende omhullende = vorm.getOmhullende();
        if (omhullende.getMinimumX() < Tekening.MIN_X ) {
            throw new DomainException("Deze vorm past niet in de tekening");
        }
        if (omhullende.getMinimumY() < Tekening.MIN_Y ) {
            throw new DomainException("Deze vorm past niet in de tekening");
        }
        if (omhullende.getMaximumX() > Tekening.MAX_X ) {
            throw new DomainException("Deze vorm past niet in de tekening");
        }
        if (omhullende.getMaximumY() > Tekening.MAX_Y ) {
            throw new DomainException("Deze vorm past niet in de tekening");
        }
        vormen.add(vorm);
    }

    public Vorm getVorm(int index){
        if (index < 0 || index >= vormen.size()){
            throw new DomainException("Index moet tussen " + 0 + " en " + (vormen.size()-1) + " liggen");
        }
        return vormen.get(index);
    }

    public int getAantalVormen(){
        return vormen.size();
    }

    public void verwijder(Vorm vorm){
        if (vorm == null){
            throw new DomainException("Vorm mag niet leeg zijn");
        }
        if (!bevat(vorm)){
            throw new DomainException("Deze vorm is niet in de lijst vormen");
        }
        vormen.remove(vorm);
    }

    public boolean bevat(Vorm vorm){
        return vormen.contains(vorm);
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof Tekening){
            Tekening t = (Tekening) o;
            if (this.getAantalVormen() != t.getAantalVormen()){
                return false;
            }
            for (Vorm vorm : t.vormen){
                if (!this.bevat(vorm)){
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public String toString(){
        String result = "Tekening: " + naam;
        for (Vorm vorm : vormen){
            result += "\n" + vorm.toString();
        }
        return result;
    }

    @Override
    public void teken(Pane root) {
        for (Vorm vorm : vormen){
            if (vorm.isZichtbaar()){
                vorm.teken(root);
            }
        }
    }
}