package db;

import model.Woord;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class WoordenLijstTabel {

    public static void newWoord(Woord woord){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("INSERT INTO pw2_g12.woordenlijst(niveau,woord) VALUES(?,?)");
            st.setString(1,woord.getNiveau());
            st.setString(2,woord.getWoord());
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static boolean isWoordInDatabase(Woord woord){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM pw2_g12.woordenlijst WHERE woord = ?");
            st.setString(1,woord.getWoord());
            ResultSet rs = st.executeQuery();
            boolean result = false;
            if (rs.next()){
                result = true;
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            return result;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static boolean isWoordInDatabase(String woord){
        return isWoordInDatabase(new Woord(woord));
    }

    public static void updateWoord(Woord oldWoord, Woord newWoord){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("UPDATE pw2_g12.woordenlijst SET niveau = ? ,woord = ? WHERE niveau = ? AND woord = ?");
            st.setString(1,newWoord.getNiveau());
            st.setString(2,newWoord.getWoord());
            st.setString(3,oldWoord.getNiveau());
            st.setString(4,oldWoord.getWoord());
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void deleteWoord(Woord woord){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("DELETE FROM pw2_g12.woordenlijst WHERE woord = ?");
            st.setString(1,woord.getWoord());
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void deleteWoord(String woord){
        deleteWoord(new Woord(woord));
    }

    public static Woord getLangsteWoord(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT woord,niveau FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            int hoogsteAantalLetters = 0;
            String langsteString = "";
            String niveau = "";
            while (rs.next()){
                if (rs.getString(1).length() > hoogsteAantalLetters){
                    langsteString = rs.getString(1);
                    hoogsteAantalLetters = langsteString.length();
                    niveau = rs.getString(2);
                }
            }
            Woord woord = new Woord(langsteString,niveau);
            st.close();
            PgConnectie.sluitConnectie(conn);
            if (langsteString.isEmpty()){
                throw new DbException("Databank heeft geen woorden");
            }
            return woord;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static Woord getKortsteWoord(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT woord,niveau FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            int kleinstAantalLetters = Integer.MAX_VALUE;
            String kleinsteString = "";
            String niveau = "";
            while (rs.next()){
                if (rs.getString(1).length() < kleinstAantalLetters){
                    kleinsteString = rs.getString(1);
                    kleinstAantalLetters = kleinsteString.length();
                    niveau = rs.getString(2);
                }
            }
            Woord woord = new Woord(kleinsteString,niveau);
            st.close();
            PgConnectie.sluitConnectie(conn);
            if (kleinsteString.isEmpty()){
                throw new DbException("Databank heeft geen woorden");
            }
            return woord;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static double gemiddeldVerschillendeLetters(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT woord FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            double result = 0;
            int count = 0;
            while (rs.next()){
                result += Woord.getVerschillendeLetters(rs.getString(1));
                count++;
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            if (count == 0){
                throw new DbException("Databank heeft geen woorden");
            }
            return result / count;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static List<Woord> getWoordenVanNiveau(String niveau){
        if (niveau == null || niveau.trim().isEmpty()){
            return getWoorden();
        }
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT woord FROM pw2_g12.woordenlijst WHERE niveau = ?");
            st.setString(1,niveau);
            ResultSet rs = st.executeQuery();
            List<Woord> woorden = new ArrayList<>();
            while (rs.next()){
                woorden.add(new Woord(rs.getString(1),niveau));
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            return woorden;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static List<Woord> getWoordenVanNiveau(String niveau, int start, int end){
        return getWoordenVanNiveau(niveau).subList(start,end);
    }

    public static int getAantalWoorden(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT count(*) FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            int count = 0;
            if (rs.next()){
                count = rs.getInt(1);
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            return count;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static List<Woord> getWoorden(int start, int end){
        return getWoorden().subList(start,end);
    }

    public static List<Woord> getWoorden(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT niveau,woord FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            List<Woord> woorden = new ArrayList<>();
            while (rs.next()){
                String woord = rs.getString(2);
                String niveau = rs.getString(1);
                woorden.add(new Woord(woord,niveau));
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            return woorden;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static Woord getRandomWoord(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT woord,niveau FROM pw2_g12.woordenlijst");
            ResultSet rs = st.executeQuery();
            List<Woord> woorden = new ArrayList<>();
            while (rs.next()){
                String woord = rs.getString(1);
                String niveau = rs.getString(2);
                woorden.add(new Woord(woord,niveau));
            }
            st.close();
            PgConnectie.sluitConnectie(conn);
            return woorden.get((int)Math.floor(Math.random()*getAantalWoorden()));
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void deleteAllWoorden(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("DELETE FROM pw2_g12.woordenlijst");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void createTable(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("CREATE TABLE pw2_g12.woordenlijst (niveau VARCHAR (15),woord VARCHAR(50) PRIMARY KEY)");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    private static void deleteTable(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("DROP TABLE IF EXISTS pw2_g12.woordenlijst");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }
}