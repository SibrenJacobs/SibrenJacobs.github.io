package db;

import model.Woord;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class WoordenLezer {
    public static WoordenLijst scanFile(String file){
        WoordenLijst woordenLijst = new WoordenLijst();
        Scanner scan;
        try{
            scan = new Scanner(new File(file));
            while(scan.hasNextLine()){
                woordenLijst.voegToe(new Woord(scan.nextLine()));
            }
            scan.close();
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
        return woordenLijst;
    }

    public static void sendFileToDatabase(String file){
        Scanner scan;
        try{
            scan = new Scanner(new File(file));
        }
        catch (FileNotFoundException e){
            throw new DbException(e.getMessage());
        }
        Connection conn = PgConnectie.openConnectie();
        try{
            while(scan.hasNextLine()){
                PreparedStatement st = conn.prepareStatement("INSERT INTO pw2_g12.woordenlijst(niveau,woord) VALUES(?,?)");
                Woord woord = Woord.WoordDefaultNiveau(scan.nextLine());

                st.setString(1,woord.getNiveau());
                st.setString(2,woord.getWoord());
                st.execute();
                st.close();
            }
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
        PgConnectie.sluitConnectie(conn);
        scan.close();
    }

    public static void woordenLijstFromDatabase(){
        try{
            PrintWriter writer = new PrintWriter("woordenlijst.txt", StandardCharsets.UTF_8);
            for (Woord woord : WoordenLijstTabel.getWoorden()){
                writer.println(woord.getWoord());
            }
            writer.close();
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static String woordenFromDatabase(){
        String result = "";
        for (Woord woord : WoordenLijstTabel.getWoorden()){
            result += woord.getWoord() + "\n";
        }
        return result;
    }

    public static void resetWoordenLijst(String nameFile){
        WoordenLijstTabel.deleteAllWoorden();
        sendFileToDatabase(nameFile);
    }

    public static void resetSpelers(){
        SpelersTable.deleteAllSpelers();
    }

    public static void main(String[] args){
        resetWoordenLijst("hangman.txt");
    }
}