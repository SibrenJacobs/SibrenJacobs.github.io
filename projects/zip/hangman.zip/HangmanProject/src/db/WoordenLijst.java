package db;

import model.DomainException;
import model.Woord;

import java.util.ArrayList;
import java.util.List;

public class WoordenLijst {
    private List<Woord> woordenLijst;

    public WoordenLijst() {
        woordenLijst = new ArrayList<>();
    }

    public List<Woord> getWoordenLijst(){
        return this.woordenLijst;
    }

    public void voegToe(Woord woord) {
        if(woord == null){
            throw new DomainException("Woord mag niet leeg zijn");
        }
        if(isInList(woord)){
            throw new DomainException("Deze string zit al in de lijst");
        }
        woordenLijst.add(woord);
    }

    public void verwijder(Woord woord){
        if(WoordenLijstTabel.isWoordInDatabase(woord)) {
            WoordenLijstTabel.deleteWoord(woord);
        }
    }

    private boolean isInList(Woord woord){
        for(Woord w: woordenLijst){
            if(woord.equals(w)) {
                return true;
            }
        }
        return false;
    }

    public int getAantalWoorden() {
        return woordenLijst.size();
    }

    public Woord getRandomWoord(){
        if (getAantalWoorden() == 0)return null;
        return woordenLijst.get((int) Math.floor(Math.random() * getAantalWoorden()));
    }
}