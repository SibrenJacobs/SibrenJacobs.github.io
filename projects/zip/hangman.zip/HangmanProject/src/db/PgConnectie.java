package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class PgConnectie {

        public static Connection openConnectie() {
		String url = "jdbc:postgresql://databanken.ucll.be:61819,databanken.ucll.be:51819/1TX31";
		Properties props = new Properties();
		try {
			props.setProperty("user","local_r0676002");
			props.setProperty("password","9EXV9A3U$1)pj");
			//61718 maakt gebruikt van transactie pooling, niet sessie, dus search_path kan niet worden ingesteld
			props.setProperty("currentSchema","pw2_g12");
			Connection conn = DriverManager.getConnection(url, props); 
			return conn;
		}
		catch (Exception e) {
        		System.err.println(e.getClass().getName()+": "+e.getMessage());
        		System.exit(0);
      		}
		return null;
   	}

        public static void sluitConnectie(Connection c) {
        	try {
        		c.close();
        	}
			catch (Exception e) {
        		System.err.println(e.getClass().getName()+": "+e.getMessage());
        		System.exit(0);
      		}
   	}
}
