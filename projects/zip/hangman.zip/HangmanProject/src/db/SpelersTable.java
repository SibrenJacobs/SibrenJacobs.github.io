package db;

import model.Speler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SpelersTable {

    public static void spelerToDatabase(Speler speler){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("INSERT INTO pw2_g12.spelers(naam,score) VALUES(?,?)");
            st.setString(1,speler.getNaam());
            st.setInt(2,speler.getScore());
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static int getAantalSpelers(){
        try {
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT count(DISTINCT naam) FROM pw2_g12.spelers");
            ResultSet rs = st.executeQuery();
            int count = -1;
            if (rs.next()){
                count = rs.getInt(1);
            }
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return count;
        }
        catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public static int getHoogsteScore(){
        try {
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT max(score) FROM pw2_g12.spelers");
            ResultSet rs = st.executeQuery();
            int score = 0;
            if (rs.next()){
                score = rs.getInt(1);
            }
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return score;
        }
        catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public static int getHoogsteScoreVanSpeler(Speler speler){
        try {
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT max(score) FROM pw2_g12.spelers WHERE naam = ?");
            st.setString(1,speler.getNaam());
            ResultSet rs = st.executeQuery();
            int score = 0;
            if (rs.next()){
                score = rs.getInt(1);
            }
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return score;
        }
        catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public static int getHoogsteScoreVanSpeler(String naam){
        return getHoogsteScoreVanSpeler(new Speler(naam));
    }

    public static int getAantalScoresVanSpeler(Speler speler){
        try {
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT count(*) FROM pw2_g12.spelers WHERE naam = ?");
            st.setString(1,speler.getNaam());
            ResultSet rs = st.executeQuery();
            int count = -1;
            if (rs.next()){
                count = rs.getInt(1);
            }
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return count;
        }
        catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public static int getAantalScoresVanSpeler(String naam){
        return getAantalScoresVanSpeler(new Speler(naam));
    }

    public static double getAverageScore(Speler speler){
        try {
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT AVG(score) FROM pw2_g12.spelers WHERE naam = ? GROUP BY naam");
            st.setString(1,speler.getNaam());
            ResultSet rs = st.executeQuery();
            double score = -1;
            if (rs.next())
                score = rs.getDouble(1);
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return score;
        }
        catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }

    public static double getAverageScore(String naam){
        return getAverageScore(new Speler(naam));
    }

    public static Speler getSpelerMetHoogsteScore(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("SELECT * FROM pw2_g12.spelers WHERE score = ?");
            st.setInt(1,getHoogsteScore());
            ResultSet rs = st.executeQuery();
            Speler speler = null;
            if (rs.next()){
                speler = new Speler(rs.getString(1));
                speler.addToScore(rs.getInt(2));
            }
            rs.close();
            PgConnectie.sluitConnectie(conn);
            return speler;
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void deleteAllSpelers(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("DELETE FROM pw2_g12.spelers WHERE score > -1");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    public static void createTable(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("CREATE TABLE pw2_g12.spelers (naam VARCHAR (20) NOT NULL,score INT NOT NULL)");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }

    private static void deleteTable(){
        try{
            Connection conn = PgConnectie.openConnectie();
            PreparedStatement st = conn.prepareStatement("DROP TABLE IF EXISTS pw2_g12.spelers");
            st.executeUpdate();
            st.close();
            PgConnectie.sluitConnectie(conn);
        }
        catch (Exception e){
            throw new DbException(e.getMessage());
        }
    }
}
