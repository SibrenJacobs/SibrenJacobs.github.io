package controller;

import db.SpelersTable;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.DomainException;
import model.HangMan;
import model.Speler;

public class HangManApp {
    private HBox hbox= new HBox();
    private HBox invoerBox = new HBox();

    private Text hintwoordUitvoer = new Text();
    private Button raadButton = new Button("raad");
    private TextField invoerLetter = new TextField("Welke letter?");
    private HangMan hangman ;
    private Label label = new Label("Geef een letter");
    private Label labelScore = new Label();
    private Button stuurScore = new Button("Stuur score");

    private TekenVenster tekening;
    private Pane pane = new Pane();

    private Alert foutenboodschap = new Alert(Alert.AlertType.WARNING);


    public HangManApp(VBox root, Speler speler) {
        this.hangman = new HangMan(speler);
        this.tekening = new TekenVenster(pane,this.hangman.getTekening());

        hintwoordUitvoer.setText(this.hangman.getHint());
        hbox.setAlignment(Pos.BOTTOM_LEFT);
        hbox.getChildren().add(hintwoordUitvoer);
        hbox.getChildren().add(raadButton);
        invoerBox.getChildren().add(invoerLetter);
        invoerBox.setDisable(true);


        root.getChildren().addAll(pane, hbox, invoerBox);


        raadButton.setOnAction(eventRaad ->{
            invoerBox.setDisable(false);
            invoerLetter.clear();
            hbox.getChildren().remove(raadButton);
        });

        invoerLetter.setOnAction(eventIngaveLetter -> {
            try {
                String invoer = invoerLetter.getText().trim();
                if (invoer.length() == 0) {
                    throw new DomainException("Geef een letter");
                }
                if (invoer.length() != 1) {
                    throw new DomainException("Geef maar één letter per keer");
                }
                char letter = invoer.charAt(0);
                if (hangman.raad(letter)){
                    if (hangman.isGewonnen()){
                        gewonenn(root,speler);
                    }
                    else hintwoordUitvoer.setText(this.hangman.getHint());
                }
                else{
                    this.tekening = new TekenVenster(pane,this.hangman.getTekening());
                    if (hangman.isGameOver()){
                        gameOver(root,speler);
                    }
                }
            }
            catch (DomainException e){
                invoerLetter.clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText(e.getMessage());
                foutenboodschap.showAndWait();
            }
            invoerLetter.clear();
        });

        stuurScore.setOnAction(eventStuurScore->{
            SpelersTable.spelerToDatabase(speler);
            stuurScore.setDisable(true);
        });
    }
    private void gameOver(VBox root, Speler speler){
        raadButton.setDisable(true);
        hbox.getChildren().clear();
        invoerBox.getChildren().clear();
        hintwoordUitvoer.setText("Jammer " + speler.getNaam() + " je hebt het woord niet geraden!! je score is " + speler.getScore());
        hbox.getChildren().add(hintwoordUitvoer);
        hbox.getChildren().add(stuurScore);
    }
    private void gewonenn(VBox root, Speler speler){
        raadButton.setDisable(true);
        hbox.getChildren().clear();
        invoerBox.getChildren().clear();
        hintwoordUitvoer.setText("Goed gedaan " + speler.getNaam() + " je score is " + speler.getScore());
        hbox.getChildren().add(hintwoordUitvoer);
        hbox.getChildren().add(stuurScore);
    }
}