package controller;

import javafx.scene.layout.Pane;
import model.Tekening;


public class TekenVenster {
    private Tekening tekening;

    public TekenVenster(Pane root, Tekening tekening){
        if (tekening == null) throw new UiException();
        this.tekening = tekening;
        this.tekening.teken(root);
    }
}