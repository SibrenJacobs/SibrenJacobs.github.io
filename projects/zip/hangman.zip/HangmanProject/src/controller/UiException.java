package controller;

public class UiException extends RuntimeException {
    public UiException(){
        super();
    }
    public UiException(String message){
        super(message);
    }
}