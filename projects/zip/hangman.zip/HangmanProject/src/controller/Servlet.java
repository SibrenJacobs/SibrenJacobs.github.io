package controller;


import db.WoordenLezer;
import db.WoordenLijstTabel;
import model.Woord;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

@WebServlet("/HangMan")
public class Servlet extends javax.servlet.http.HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String command = "";
        if(request.getParameter("command") != null){
            command = request.getParameter("command");
        }
        String destination;
        switch (command){
            case "showHome" :
                destination = "index.jsp";
                break;
            case "showOverview" :
                destination = overview(request, response);
                break;
            case "showForm":
                destination = formulier(request,response);
                break;
            case "change":
                destination = change(request,response);
                break;
            case "delete":
                destination = delete(request, response);
                break;
            case "add" :
                destination = add(request, response);
                break;
            case "download":
                destination = download(request, response);
                break;
            default:
                destination = "overzicht.jsp";
        }
        RequestDispatcher view = request.getRequestDispatcher(destination);
        view.forward(request, response);
    }

    private String overview(HttpServletRequest request, HttpServletResponse response) {
        if (request.getParameter("commando") != null){

        }
        request.setAttribute("filter",request.getParameter("filter"));
        return "overzicht.jsp";
    }

    private String formulier(HttpServletRequest request, HttpServletResponse response){
        String woord = "";
        if (request.getParameter("woord") != null){
            woord = request.getParameter("woord");
        }
        request.setAttribute("woord",woord);
        return "formulier.jsp";
    }

    private String change(HttpServletRequest request, HttpServletResponse response){
        String woord = request.getParameter("woord");
        WoordenLijstTabel.deleteWoord(woord);
        request.setAttribute("woord",woord);
        return "formulier.jsp";
    }

    private String delete(HttpServletRequest request, HttpServletResponse response) {
        String woord = request.getParameter("woord");
        WoordenLijstTabel.deleteWoord(woord);
        return overview(request, response);
    }

    private String add(HttpServletRequest request, HttpServletResponse response){
        String string = request.getParameter("woord");
        String niveau = request.getParameter("niveau");
        if (string.trim().isEmpty()){
            return "formulier.jsp";
        }
        if (WoordenLijstTabel.isWoordInDatabase(string)){
            request.setAttribute("woord","Het woord '" + string + "' zit al in de woordenlijst");
            return "formulier.jsp";
        }
        Woord woord;
        if (niveau == null || niveau.trim().isEmpty()) {
            woord = new Woord(string);
        }else if (niveau.equals("Default")){
            woord = Woord.WoordDefaultNiveau(string);
        }
        else woord = new Woord(string,niveau);
        WoordenLijstTabel.newWoord(woord);
        return overview(request, response);
    }

    private String download(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain");
        response.setHeader("Content-disposition", "attachment; filename=woordenlijst.txt");
        response.setCharacterEncoding("UTF-8");

        try(InputStream in = new ByteArrayInputStream(WoordenLezer.woordenFromDatabase().getBytes());
            OutputStream out = response.getOutputStream()) {

            byte[] buffer = new byte[4096];

            int numBytesRead;
            while ((numBytesRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, numBytesRead);
            }
        }
        return "overzicht.jsp";
    }
}
