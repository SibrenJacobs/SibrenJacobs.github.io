package controller;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Speler;

public class FxHangManApp extends Application {

    @Override
    public void start(Stage primaryStage) {

        VBox root = new VBox();
        Scene scene = new Scene(root,400,450);
        TextField invoerNaam = new TextField("Geef de naam van de speler");
        root.getChildren().add(invoerNaam);

        primaryStage.setScene(scene);

        invoerNaam.setOnAction( eventIngaveNaam -> {
                    primaryStage.setTitle(invoerNaam.getText());
                    root.getChildren().clear();
                    new HangManApp(root,new Speler(invoerNaam.getText()));
        });
        primaryStage.show();
    }
}